﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KubilayProje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=Proje; user ID=postgres;  password=12345");
        private void lblAModel_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblAS_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnlist_Click(object sender, EventArgs e)
        {

            string sorgu = "select * from kategori inner join urun on kategori.kategori_id=urun.kategori_id order by urun_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnekle_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlCommand sorgu = new NpgsqlCommand("insert into urun(urun_adi,stok,kategori_id,kargo_id,sube_id) values(@p1,@p2,@p3,@p4,@p5)", baglanti);
            sorgu.Parameters.AddWithValue("@p1", txturunadi.Text);
            sorgu.Parameters.AddWithValue("@p2", int.Parse(txtstok.Text));
            sorgu.Parameters.AddWithValue("@p3", int.Parse(txtkategoriid.Text));
            sorgu.Parameters.AddWithValue("@p4", int.Parse(txtkargono.Text));
            sorgu.Parameters.AddWithValue("@p5", int.Parse(txtsubeid.Text));
            sorgu.ExecuteNonQuery();
            
            baglanti.Close();

            string sorgu2 = "select * from kategori inner join urun on kategori.kategori_id=urun.kategori_id order by urun_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu2, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            MessageBox.Show("Ürün Eklendi");
        }

        private void btnara_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kategori inner join urun on kategori.kategori_id=urun.kategori_id where kategori_adi like'" + txtkategoriadi.Text + "%' order by urun_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand sorgu = new NpgsqlCommand("delete from urun where urun_id=@p1", baglanti);
            sorgu.Parameters.AddWithValue("@p1", int.Parse(txturunid.Text));
            sorgu.ExecuteNonQuery();


            baglanti.Close();


            string sorgu2 = "select * from kategori inner join urun on kategori.kategori_id=urun.kategori_id order by urun_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu2, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            MessageBox.Show("Ürün Silindi");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand sorgu = new NpgsqlCommand("insert into siparis(musteri_id,urun_id,personel_id) values(@p1,@p2,@p3)", baglanti);
            sorgu.Parameters.AddWithValue("@p1", int.Parse(txtmusteriid.Text));
            sorgu.Parameters.AddWithValue("@p2", int.Parse(txturunid.Text));
            sorgu.Parameters.AddWithValue("@p3", int.Parse(txtsatistemsilcisiid.Text));
            sorgu.ExecuteNonQuery();

            baglanti.Close();

            string sorgu2 = "select * from kategori inner join urun on kategori.kategori_id=urun.kategori_id order by urun_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu2, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            MessageBox.Show("Sipariş Eklendi");
        }

        private void btngncl_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlCommand sorgu = new NpgsqlCommand("UPDATE urun SET urun_adi = @p1, stok = @p2, kategori_id=@p3, sube_id=@p4, kargo_id=@p5 WHERE urun_id= @p6;", baglanti);
            sorgu.Parameters.AddWithValue("@p1", txturunadi.Text);
            sorgu.Parameters.AddWithValue("@p2", int.Parse(txtstok.Text));
            sorgu.Parameters.AddWithValue("@p3", int.Parse(txtkategoriid.Text));
            sorgu.Parameters.AddWithValue("@p4", int.Parse(txtsubeid.Text));
            sorgu.Parameters.AddWithValue("@p5", int.Parse(txtkargono.Text));
            sorgu.Parameters.AddWithValue("@p6", int.Parse(txturunid.Text));
            sorgu.ExecuteNonQuery();

            baglanti.Close();

            string sorgu2 = "select * from kategori inner join urun on kategori.kategori_id=urun.kategori_id order by urun_id";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu2, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            MessageBox.Show("Ürün Güncellendi");
        }
    }
}
